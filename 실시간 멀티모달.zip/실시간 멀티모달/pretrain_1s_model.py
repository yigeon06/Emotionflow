import os
import re
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Concatenate, Multiply, Flatten
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping
from tensorflow.keras.utils import register_keras_serializable
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import matplotlib.pyplot as plt
# calibrate() 안 debug 로드 전에 추가
try:
    # TF-Keras 2.10+ 의 경로
    from tensorflow.keras.engine.functional import Functional
    debug_path = "tensorflow.keras.engine.functional"
except ImportError:
    try:
        # 저수준 내부 모듈 경로
        from tensorflow.python.keras.engine.functional import Functional
        debug_path = "tensorflow.python.keras.engine.functional"
    except ImportError:
        # 만약 또 실패하면 Keras standalone fallback
        from keras.engine.functional import Functional
        debug_path = "keras.engine.functional"

print(f"[Debug] Functional import 경로: {debug_path}")


# ───────────────────────────────────────────────────────────────
# 설정
# ───────────────────────────────────────────────────────────────
BASE_DIR      = "/home/bcml1/sigenv/_7월/multimodal_livetime"
EYE_DIR       = os.path.join(BASE_DIR, "features_imp")
FACE_DIR      = os.path.join(BASE_DIR, "face_features")
RPPG_DIR      = os.path.join(BASE_DIR, "rppg_features")
MOUTH_DIR     = "/home/bcml1/yigeon06/Mouth/feature_1s_segment"

LABEL_ROOT    = "/home/bcml1/2025_EMOTION/DEAP_5labels"
RESULT_DIR    = os.path.join(BASE_DIR, "multi_e_m_f_r_gate_fusion2")
os.makedirs(RESULT_DIR, exist_ok=True)

SEG_LEN_EYE   = 1
SEG_LEN_FACE  = 1
SEG_LEN_MOUTH = 1
SEG_LEN_RPPG  = 50

TEST_RATIO    = 0.2
BATCH_SIZE    = 16
EPOCHS        = 100
NUM_SUBJ      = 20
NUM_TRIAL     = 40

# pretrained extractor weights
PRETRAIN_EYE   = os.path.join(BASE_DIR, 'eye_model', 'best_eye.weights.h5')
PRETRAIN_FACE  = os.path.join(BASE_DIR, 'face_model', 'best_face.weights.h5')
PRETRAIN_MOUTH = "/home/bcml1/yigeon06/Mouth/Extra_result2/best_mouth_model.keras"  # 필요시 조정

# ───────────────────────────────────────────────────────────────
# Custom layer: gate 분할
# ───────────────────────────────────────────────────────────────
@register_keras_serializable(package='custom_layers')
class SplitModality(tf.keras.layers.Layer):
    def __init__(self, idx, **kwargs):
        super().__init__(**kwargs)
        self.idx = idx
    def call(self, inputs):
        return tf.expand_dims(inputs[:, self.idx], -1)
    def get_config(self):
        cfg = super().get_config()
        cfg.update({'idx': self.idx})
        return cfg
    @classmethod
    def from_config(cls, config):
        return cls(**config)

# ───────────────────────────────────────────────────────────────
# Segment loader (label 4 제거 포함)
# ───────────────────────────────────────────────────────────────
def prepare_segments(base_dir, label_root, seg_len, is_rppg=False, modality_name="eye"):
    X, y, meta = [], [], []
    for subj in range(1, NUM_SUBJ+1):
        sid = f"s{subj:02d}"
        label_file = os.path.join(label_root, f"subject{subj:02d}.npy")
        if not os.path.isfile(label_file):
            continue
        labels = np.load(label_file)
        subj_dir = os.path.join(base_dir, sid)
        if not os.path.isdir(subj_dir):
            continue
        for fname in sorted(os.listdir(subj_dir)):
            if not fname.endswith('.npy'):
                continue
            if is_rppg:
                m = re.match(r"trial(\d{2})_csp_rppg_multiclass\.npy", fname)
            else:
                if "mouth" in modality_name.lower():
                    m = re.match(rf"{sid}_trial(\d{{2}})_features\.npy", fname)
                else:
                    m = re.match(rf"{sid}_trial(\d{{2}})\.npy", fname)
            if not m:
                continue
            trial_idx = int(m.group(1))
            label = int(labels[trial_idx-1])
            if label == 4:
                continue
            data = np.load(os.path.join(subj_dir, fname))
            length = data.shape[1]
            for i in range(0, length, seg_len):
                j = i + seg_len
                if j > length:
                    break
                seg = data[:, i:j]
                if seg.shape[1] != seg_len:
                    continue
                X.append(seg.T)  # (time, feature_dim)
                y.append(label)
                meta.append((sid, trial_idx, i // seg_len))
    if not X:
        return np.empty((0, seg_len, 0)), np.array([], dtype=int), []
    return np.stack(X, axis=0), np.array(y, dtype=int), meta

# ───────────────────────────────────────────────────────────────
# 정규화 and NaN/Inf 제거 (train/test 분리 전 & 후에 재사용)
# ───────────────────────────────────────────────────────────────
def clean_and_normalize(X, mean=None, std=None):
    mask = ~np.isnan(X).any(axis=(1,2)) & ~np.isinf(X).any(axis=(1,2))
    X_valid = X[mask]
    if X_valid.size == 0:
        return X, mask, mean, std
    if mean is None or std is None:
        N, T, D = X_valid.shape
        flat = X_valid.reshape(-1, D)
        mean = flat.mean(0)
        std = flat.std(0) + 1e-6
    X_norm = ((X_valid.reshape(-1, X_valid.shape[-1]) - mean) / std).reshape(X_valid.shape)
    X_out = X.copy()
    X_out[mask] = X_norm
    return X_out, mask, mean, std

# ───────────────────────────────────────────────────────────────
# 라벨 재매핑: contiguous 0..C-1
# ───────────────────────────────────────────────────────────────
def remap_labels(y):
    unique = np.unique(y)
    cmap = {v:i for i,v in enumerate(unique)}
    return np.array([cmap[v] for v in y], dtype=int), cmap

# ───────────────────────────────────────────────────────────────
# invalid 샘플 설명
# ───────────────────────────────────────────────────────────────
def describe_invalid_samples(name, X, mask, metas, limit=10):
    invalid_idx = np.where(~mask)[0]
    if invalid_idx.size == 0:
        print(f"[{name}] 모두 유효한 샘플입니다.")
        return
    print(f"[{name}] NaN/Inf 제거 대상: {len(invalid_idx)}개")
    for i in invalid_idx[:limit]:
        sample = X[i]
        mn = np.nanmin(sample)
        mx = np.nanmax(sample)
        print(f"  index {i}, meta {metas[i]}, min {mn:.4f}, max {mx:.4f}")
    if len(invalid_idx) > limit:
        print(f"  ...처음 {limit}개만 표시 (총 {len(invalid_idx)})")

# ───────────────────────────────────────────────────────────────
# 공통 meta intersection helper (유연한 정합)
# ───────────────────────────────────────────────────────────────
def intersect_meta_indices(meta_dict):
    sets = {k: set(v) for k, v in meta_dict.items()}
    common = sorted(list(set.intersection(*sets.values())))
    if not common:
        raise ValueError("모든 modality 사이에 공통 meta가 없습니다.")
    idx_maps = {k: {m: i for i, m in enumerate(meta_dict[k])} for k in meta_dict}
    aligned = {}
    for k in meta_dict:
        indices = [idx_maps[k][m] for m in common]
        aligned[k] = indices
    return common, aligned

# ───────────────────────────────────────────────────────────────
# 메인
# ───────────────────────────────────────────────────────────────
if __name__ == '__main__':
    # 1) segment 로드
    X_eye,  y_eye,  meta_eye  = prepare_segments(EYE_DIR,  LABEL_ROOT, SEG_LEN_EYE, is_rppg=False, modality_name="eye")
    X_face, y_face, meta_face = prepare_segments(FACE_DIR, LABEL_ROOT, SEG_LEN_FACE, is_rppg=False, modality_name="face")
    X_rppg, y_rppg, meta_rppg = prepare_segments(RPPG_DIR, LABEL_ROOT, SEG_LEN_RPPG, is_rppg=True, modality_name="rppg")
    X_mouth, y_mouth, meta_mouth = prepare_segments(MOUTH_DIR, LABEL_ROOT, SEG_LEN_MOUTH, is_rppg=False, modality_name="mouth")

    # 2) 존재 확인
    if X_eye.size == 0: raise FileNotFoundError(f"Eye empty {EYE_DIR}")
    if X_face.size == 0: raise FileNotFoundError(f"Face empty {FACE_DIR}")
    if X_rppg.size == 0: raise FileNotFoundError(f"rPPG empty {RPPG_DIR}")
    if X_mouth.size == 0: raise FileNotFoundError(f"Mouth empty {MOUTH_DIR}")

    # --- 진단: 원본 라벨 분포 (label 4 제외된 상태) ---
    def label_counts(y, name):
        unique, counts = np.unique(y, return_counts=True)
        print(f"[{name}] label distribution before remap:", dict(zip(unique, counts)))
    label_counts(y_eye, "eye (original)")
    label_counts(y_face, "face (original)")
    label_counts(y_rppg, "rppg (original)")
    label_counts(y_mouth, "mouth (original)")

    # 3) meta 정합: strict 체크하고, 안 맞으면 intersection 방식으로 정렬
    try:
        if not (len(meta_eye) == len(meta_face) == len(meta_rppg) == len(meta_mouth)):
            raise AssertionError("Meta length mismatch across modalities")
        for me, mf, mr, mm in zip(meta_eye, meta_face, meta_rppg, meta_mouth):
            if not (me[0:2] == mf[0:2] == mr[0:2] == mm[0:2]):
                raise AssertionError(f"Meta mismatch: {me}, {mf}, {mr}, {mm}")
        aligned_indices = {
            'eye': list(range(len(meta_eye))),
            'face': list(range(len(meta_face))),
            'rppg': list(range(len(meta_rppg))),
            'mouth': list(range(len(meta_mouth)))
        }
        common_meta = meta_eye
        used_strict = True
    except AssertionError:
        print("[WARN] strict meta check failed; falling back to intersection alignment.")
        meta_dict = {
            'eye': meta_eye,
            'face': meta_face,
            'rppg': meta_rppg,
            'mouth': meta_mouth
        }
        common_meta, aligned_indices = intersect_meta_indices(meta_dict)

        # *** 디버깅: 각 modality에서 strict 기준에서 교집합으로 빠진 meta 확인 ***
        def diff_meta(orig_meta, kept_indices):
            return [m for i, m in enumerate(orig_meta) if i not in kept_indices]

        dropped_eye = diff_meta(meta_eye, aligned_indices['eye'])
        dropped_face = diff_meta(meta_face, aligned_indices['face'])
        dropped_rppg = diff_meta(meta_rppg, aligned_indices['rppg'])
        dropped_mouth = diff_meta(meta_mouth, aligned_indices['mouth'])

        print(f"[DEBUG] dropped counts by modality due to intersection:")
        print(f"  eye:   {len(dropped_eye)} dropped")
        print(f"  face:  {len(dropped_face)} dropped")
        print(f"  rppg:  {len(dropped_rppg)} dropped")
        print(f"  mouth: {len(dropped_mouth)} dropped")

        with open(os.path.join(RESULT_DIR, 'dropped_meta_per_modality.txt'), 'w') as f:
            f.write("Dropped meta per modality (strict->intersection):\n")
            f.write(f"\n[eye] ({len(dropped_eye)})\n")
            for m in dropped_eye:
                f.write(f"{m}\n")
            f.write(f"\n[face] ({len(dropped_face)})\n")
            for m in dropped_face:
                f.write(f"{m}\n")
            f.write(f"\n[rppg] ({len(dropped_rppg)})\n")
            for m in dropped_rppg:
                f.write(f"{m}\n")
            f.write(f"\n[mouth] ({len(dropped_mouth)})\n")
            for m in dropped_mouth:
                f.write(f"{m}\n")

        # reindex data based on intersection
        X_eye = X_eye[aligned_indices['eye']]
        X_face = X_face[aligned_indices['face']]
        X_rppg = X_rppg[aligned_indices['rppg']]
        X_mouth = X_mouth[aligned_indices['mouth']]
        y_eye = y_eye[aligned_indices['eye']]
        y_face = y_face[aligned_indices['face']]
        y_rppg = y_rppg[aligned_indices['rppg']]
        y_mouth = y_mouth[aligned_indices['mouth']]
        used_strict = False

    # 4) 라벨 설정 (eye 기준으로 contiguous re-map)
    y = y_eye  # label 4은 loader에서 이미 제거됨
    y, label_map = remap_labels(y)
    num_classes = len(label_map)
    print(f"[INFO] 클래스 매핑: {label_map}")
    unique, counts = np.unique(y, return_counts=True)
    print("[after remap] label distribution:", dict(zip(unique, counts)))

    # 5) NaN/Inf 제거 + 초기 정규화 (split 이전)
    X_eye, mask_eye, mean_eye, std_eye = clean_and_normalize(X_eye)
    X_face, mask_face, mean_face, std_face = clean_and_normalize(X_face)
    X_rppg, mask_rppg, mean_rppg, std_rppg = clean_and_normalize(X_rppg)
    X_mouth, mask_mouth, mean_mouth, std_mouth = clean_and_normalize(X_mouth)

    # invalid sample 설명
    describe_invalid_samples('eye', X_eye, mask_eye, meta_eye)
    describe_invalid_samples('face', X_face, mask_face, meta_face)
    describe_invalid_samples('rppg', X_rppg, mask_rppg, meta_rppg)
    describe_invalid_samples('mouth', X_mouth, mask_mouth, meta_mouth)

    # 교집합 기반으로 남은 유효 인덱스
    valid_mask = mask_eye & mask_face & mask_rppg & mask_mouth
    removed_meta = [common_meta[i] for i in np.where(~valid_mask)[0]]
    with open(os.path.join(RESULT_DIR, 'invalid_meta.txt'), 'w') as f:
        for m in removed_meta:
            f.write(f"{m}\n")
    print(f"[INFO] 공통으로 유효한 샘플 개수: {valid_mask.sum()}")

    # 빠진 샘플 진단 (label 4 제외 후 remap된 기준)
    y_full_remapped, _ = remap_labels(y_eye)
    kept_indices = np.nonzero(valid_mask)[0]
    dropped_indices = np.setdiff1d(np.arange(len(y_full_remapped)), kept_indices)
    if len(dropped_indices) > 0:
        print(f"[WARN] 총 {len(dropped_indices)}개 샘플이 NaN/Inf 또는 alignment/clean에서 빠졌습니다. 라벨별 분포:")
        dropped_labels = y_full_remapped[dropped_indices]
        unique_d, counts_d = np.unique(dropped_labels, return_counts=True)
        print(dict(zip(unique_d, counts_d)))
    else:
        print("[INFO] label 4 외에 NaN/Inf나 alignment/clean으로 빠진 샘플 없음.")

    # 필터링 적용
    X_eye = X_eye[valid_mask]
    X_face = X_face[valid_mask]
    X_rppg = X_rppg[valid_mask]
    X_mouth = X_mouth[valid_mask]
    y = y[valid_mask]
    print(f"[INFO] shapes after clean/filter: eye {X_eye.shape}, face {X_face.shape}, rppg {X_rppg.shape}, mouth {X_mouth.shape}, labels {y.shape}")
    
    # 6) train/test split (stratified)
    Xe_tr, Xe_te, Xf_tr, Xf_te, Xr_tr, Xr_te, Xm_tr, Xm_te, y_tr, y_te = train_test_split(
        X_eye, X_face, X_rppg, X_mouth, y,
        test_size=TEST_RATIO, random_state=42, stratify=y
    )

    # 7) train에서 다시 정규화 통계 구하고 적용 (leakage 방지)
    Xe_tr, _, mean_eye, std_eye = clean_and_normalize(Xe_tr, mean=None, std=None)
    Xe_te, _, _, _ = clean_and_normalize(Xe_te, mean=mean_eye, std=std_eye)

    Xf_tr, _, mean_face, std_face = clean_and_normalize(Xf_tr, mean=None, std=None)
    Xf_te, _, _, _ = clean_and_normalize(Xf_te, mean=mean_face, std=std_face)

    Xr_tr, _, mean_rppg, std_rppg = clean_and_normalize(Xr_tr, mean=None, std=None)
    Xr_te, _, _, _ = clean_and_normalize(Xr_te, mean=mean_rppg, std=std_rppg)

    Xm_tr, _, mean_mouth, std_mouth = clean_and_normalize(Xm_tr, mean=None, std=None)
    Xm_te, _, _, _ = clean_and_normalize(Xm_te, mean=mean_mouth, std=std_mouth)

    # 8) extractor 로드 & feature extractor
    from Eye_model import build_eye_model
    from Face_model import build_face_model
    from Mouth_model import build_mouth_model

    eye_base = build_eye_model(num_classes=num_classes, seq_length=SEG_LEN_EYE, feature_dim=Xe_tr.shape[2])
    try:
        eye_base.load_weights(PRETRAIN_EYE)
    except ValueError:
        eye_base.load_weights(PRETRAIN_EYE, by_name=True, skip_mismatch=True)
        print("[WARN] eye_base weight load fallback")

    face_base = build_face_model(num_classes=num_classes, seq_length=SEG_LEN_FACE, feature_dim=Xf_tr.shape[2])
    try:
        face_base.load_weights(PRETRAIN_FACE)
    except ValueError:
        face_base.load_weights(PRETRAIN_FACE, by_name=True, skip_mismatch=True)
        print("[WARN] face_base weight load fallback")

    mouth_base = build_mouth_model(num_classes=num_classes, seq_length=SEG_LEN_MOUTH, feature_dim=Xm_tr.shape[2])
    try:
        mouth_base.load_weights(PRETRAIN_MOUTH, by_name=True, skip_mismatch=True)
    except Exception:
        print("[WARN] mouth_base pretrained weight not loaded; training end-to-end")

    eye_ext = Model(eye_base.input, eye_base.layers[-2].output)
    face_ext = Model(face_base.input, face_base.layers[-2].output)
    mouth_ext = Model(mouth_base.input, mouth_base.layers[-2].output)
    eye_ext.trainable = True
    face_ext.trainable = True
    mouth_ext.trainable = True  # freeze pretrained extractors

    # 9) rPPG projection
    in_r = Input(shape=(SEG_LEN_RPPG, Xr_tr.shape[2]), name='rppg_input')
    xr = Flatten(name='rppg_flat')(in_r)
    pdim = eye_ext.output_shape[-1]
    feat_r = Dense(pdim, activation='relu', name='rppg_proj')(xr)

    # 10) fusion with gating
    in_e = Input(shape=(SEG_LEN_EYE, Xe_tr.shape[2]), name='eye_input')
    in_f = Input(shape=(SEG_LEN_FACE, Xf_tr.shape[2]), name='face_input')
    in_mouth = Input(shape=(SEG_LEN_MOUTH, Xm_tr.shape[2]), name='mouth_input')

    fe = eye_ext(in_e)
    ff = face_ext(in_f)
    fm = mouth_ext(in_mouth)

    concat = Concatenate(name='concat')([fe, ff, fm, feat_r])
    gates = Dense(4, activation='softmax', name='gate')(concat)
    we = SplitModality(0, name='we')(gates)
    wf = SplitModality(1, name='wf')(gates)
    wm = SplitModality(2, name='wm')(gates)
    wr = SplitModality(3, name='wr')(gates)

    pe = Multiply(name='pe')([fe, we])
    pf = Multiply(name='pf')([ff, wf])
    pm = Multiply(name='pm')([fm, wm])
    pr = Multiply(name='pr')([feat_r, wr])

    fused = Concatenate(name='fused')([pe, pf, pm, pr])
    x = Dense(128, activation='relu', name='dense')(fused)
    out = Dense(num_classes, activation='softmax', name='out')(x)

    model = Model([in_e, in_f, in_r, in_mouth], out, name='gated4')
    model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    model.summary()

    # 11) training
    # cp = ModelCheckpoint(os.path.join(RESULT_DIR,'best_0803_weights.h5'),
    #                      save_best_only=True, save_weights_only=True, monitor='val_accuracy', save_format='keras')

    cp = ModelCheckpoint(
        os.path.join(RESULT_DIR, 'best_0803.weights.h5'),
        save_best_only=True,
        save_weights_only=True,
        monitor='val_accuracy'
    )

    es = EarlyStopping(patience=10, restore_best_weights=True, monitor='val_loss')
    hist = model.fit([Xe_tr, Xf_tr, Xr_tr, Xm_tr], y_tr,
                     validation_split=0.2, epochs=EPOCHS,
                     batch_size=BATCH_SIZE, callbacks=[es, cp], verbose=2)

    # 전체 모델을 native .keras 포맷으로 저장
    model.save(os.path.join(RESULT_DIR, 'best_0803.keras'), save_format='keras') # custom layer 직렬화 될 것

    # 12) evaluation
    loss, acc = model.evaluate([Xe_te, Xf_te, Xr_te, Xm_te], y_te)
    print(f"Test: loss={loss:.4f}, acc={acc:.4f}")
    pred = model.predict([Xe_te, Xf_te, Xr_te, Xm_te]).argmax(axis=1)
    rep = classification_report(y_te, pred)
    cm = confusion_matrix(y_te, pred)
    with open(os.path.join(RESULT_DIR,'report.txt'),'w') as f: f.write(rep)
    np.savetxt(os.path.join(RESULT_DIR,'cm.txt'), cm, fmt='%d')
    plt.figure(); plt.plot(hist.history['loss'], label='loss'); plt.plot(hist.history['val_loss'], label='val_loss'); plt.legend(); plt.title("Loss"); plt.savefig(os.path.join(RESULT_DIR,'loss.png'))
    plt.figure(); plt.plot(hist.history['accuracy'], label='acc'); plt.plot(hist.history['val_accuracy'], label='val_acc'); plt.legend(); plt.title("Accuracy"); plt.savefig(os.path.join(RESULT_DIR,'acc.png'))

    # 13) permutation importance
    print("\n[Permutation importance per modality]")
    base_pred = model.predict([Xe_te, Xf_te, Xr_te, Xm_te]).argmax(axis=1)
    base_acc = accuracy_score(y_te, base_pred)
    print(f"Base accuracy: {base_acc:.4f}")
    modal_names = ['eye', 'face', 'rppg', 'mouth']
    X_te_list = [Xe_te, Xf_te, Xr_te, Xm_te]
    perm_results = {}
    def permutation_importance(model, X_list, y_true, idx, n_rounds=5):
        drops = []
        for _ in range(n_rounds):
            X_perm = [x.copy() for x in X_list]
            np.random.shuffle(X_perm[idx])
            pred = model.predict(X_perm, verbose=0).argmax(axis=1)
            drops.append(base_acc - accuracy_score(y_true, pred))
        return float(np.mean(drops)), float(np.std(drops))
    for i, name in enumerate(modal_names):
        mean_drop, std_drop = permutation_importance(model, X_te_list, y_te, i)
        perm_results[name] = mean_drop
        print(f"{name:6} perm drop: {mean_drop:.4f} ± {std_drop:.4f}")
    total_perm = sum(perm_results.values())
    if total_perm > 0:
        print("\nPermutation relative importance:")
        for name in modal_names:
            print(f"{name:6} {perm_results[name]/total_perm:.3f}")
    with open(os.path.join(RESULT_DIR, 'permutation_importance.txt'), 'w') as f:
        f.write(f"Base accuracy: {base_acc:.4f}\n")
        for name in modal_names:
            drop = perm_results[name]
            rel = drop / total_perm if total_perm > 0 else 0.0
            f.write(f"{name}: drop={drop:.4f}, relative={rel:.3f}\n")

    # 14) ablation study
    print("\n[Ablation study per modality]")
    ablation_results = {}
    def zero_out(X): return np.zeros_like(X)
    for i, name in enumerate(modal_names):
        X_ablate = [Xe_te.copy(), Xf_te.copy(), Xr_te.copy(), Xm_te.copy()]
        X_ablate[i] = zero_out(X_ablate[i])
        pred_ablate = model.predict(X_ablate, verbose=0).argmax(axis=1)
        acc_ablate = accuracy_score(y_te, pred_ablate)
        drop = base_acc - acc_ablate
        ablation_results[name] = drop
        print(f"{name:6} ablation drop: {drop:.4f} (acc: {acc_ablate:.4f})")
    total_ablation = sum(ablation_results.values())
    if total_ablation > 0:
        print("\nAblation relative importance:")
        for name in modal_names:
            print(f"{name:6} {ablation_results[name]/total_ablation:.3f}")
    with open(os.path.join(RESULT_DIR, 'ablation_results.txt'), 'w') as f:
        f.write(f"Base accuracy: {base_acc:.4f}\n")
        for name in modal_names:
            drop = ablation_results[name]
            rel = drop / total_ablation if total_ablation > 0 else 0.0
            f.write(f"{name}: drop={drop:.4f}, relative={rel:.3f}\n")
