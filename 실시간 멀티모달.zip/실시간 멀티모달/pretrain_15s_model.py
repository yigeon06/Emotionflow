import os, cv2
import glob
import numpy as np
import tensorflow as tf
from sklearn.model_selection import train_test_split
from tensorflow.keras.layers import (
    Input, Conv3D, MaxPool3D, Dropout,
    Flatten, Dense
)
from tensorflow.keras.models import Model
import re
from sklearn.utils import class_weight
from tensorflow.keras.callbacks import Callback
from tensorflow.keras import mixed_precision
import tensorflow_addons as tfa

# GPU 및 Mixed Precision 설정
policy = mixed_precision.Policy('mixed_float16')
mixed_precision.set_global_policy(policy)
print("[Init] Available GPUs:", tf.config.list_physical_devices('GPU'))

gpus = tf.config.list_physical_devices('GPU')
if gpus:
    tf.config.experimental.set_memory_growth(gpus[0], True)
    tf.config.experimental.set_virtual_device_configuration(
        gpus[0],
        [tf.config.experimental.VirtualDeviceConfiguration(memory_limit=20000)]
    )
    print(f"[GPU] Memory growth enabled, limit set to 20000 MB on {gpus[0]}")
    
    
# ── 0) 결과 저장 경로 ────────────────────────────────────
RESULT_DIR = "/home/bcml1/sigenv/_7월/face_micro/restart3_apex8/3D_CNN_aug"
os.makedirs(RESULT_DIR, exist_ok=True)

def build_microexp3dstcnn(
    input_shape=(90, 64, 64, 1),
    num_classes=4,
    dropout_rate=0.3
):
    inp = Input(shape=input_shape, name="video_in")

    # 1) 3D Convolution
    x = Conv3D(
        filters=32,
        kernel_size=(15, 3, 3),
        strides=(1, 1, 1),
        padding="valid",
        activation="relu",
        name="conv3d_1"
    )(inp)

    # 2) 3D Max‑Pooling
    x = MaxPool3D(
        pool_size=(3, 3, 3),
        strides=(3, 3, 3),
        padding="valid",
        name="pool3d_1"
    )(x)

    # 3) Dropout
    x = Dropout(dropout_rate, name="dropout_1")(x)

    # 4) Flatten → FC
    x = Flatten(name="flatten")(x)
    x = Dense(128, activation="relu", name="fc1")(x)
    x = Dropout(dropout_rate, name="dropout_2")(x)

    # 5) 최종 분류층
    out = Dense(num_classes, activation="softmax", name="emotion_out")(x)

    model = Model(inp, out, name="MicroExpSTCNN")
    model.compile(
        optimizer="adam",
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"]
    )
    return model

# 증강 반복 횟수 (k배 증강)
AUGMENT_TIMES = 1
BATCH_SIZE = 16

# 증강 레이어 외부 생성
rot = tf.keras.layers.RandomRotation(0.1)
trans = tf.keras.layers.RandomTranslation(0.1,0.1)
zoom = tf.keras.layers.RandomZoom(0.1,0.1)
contrast = tf.keras.layers.RandomContrast(0.2)
gnoise = tf.keras.layers.GaussianNoise(0.01)

# 증강 함수
@tf.function
def augment(clip, label):
    clip = tf.image.random_flip_left_right(clip)
    clip = rot(clip)
    # clip = trans(clip)
    # clip = zoom(clip)
    clip = contrast(clip)
    clip = gnoise(clip)
    # 블러/샤픈 랜덤 적용
    def blur(im):
        return tfa.image.gaussian_filter2d(im, filter_shape=(3,3), sigma=1.0)
    def sharpen(im):
        b = tfa.image.gaussian_filter2d(im, filter_shape=(3,3), sigma=1.0)
        return tf.clip_by_value(im + (im - b), 0.0, 1.0)
    choice = tf.random.uniform([])
    clip = tf.cond(choice < 0.5,
                   lambda: tf.map_fn(blur, clip),
                   lambda: tf.map_fn(sharpen, clip))
    
    clip = tf.cast(clip, tf.float32)      # float16 → float32 로 캐스팅
    return clip, label

def get_label(fpath, label_dir):
    """
    fpath: apex_segments/*.npz 파일 경로
    label_dir: subject{sid:02d}.npy 레이블 디렉토리
    """
    # 파일 이름에서 subject ID 와 trial ID 추출
    m = re.match(r".*s(\d+)_trial(\d+)\.npz", os.path.basename(fpath))
    sid, tid = int(m.group(1)), int(m.group(2)) - 1
    # subject{sid:02d}.npy 에서 해당 trial 의 레이블 읽기
    arr = np.load(os.path.join(label_dir, f"subject{sid:02d}.npy"))
    return int(arr[tid])

# ── 2) 데이터 로더 ────────────────────────────────────

def load_all_data(file_list, label_dir, L=90, num_segments=8, img_size=64):
    Xs, ys = [], []
    for fpath in file_list:
        z = np.load(fpath)
        clips = z["multi_clip"]
        y = get_label(fpath, label_dir)
        if y == 4:
            continue
        for seg in range(clips.shape[0]):
            clip = clips[seg].reshape((L,112,112,3)).astype(np.float32) / 255.0
            gray = np.dot(clip[...,:3], [0.299,0.587,0.114])
            out  = np.zeros((L, img_size, img_size), np.float32)
            for t in range(L):
                out[t] = cv2.resize(gray[t], (img_size, img_size))
            Xs.append(out[..., np.newaxis])
            ys.append(y)
    X = np.stack(Xs, axis=0)   # (N,90,64,64,1)
    y = np.array(ys, dtype=np.int32)
    return X, y

class NativeKerasCheckpoint(Callback):
    def __init__(self, filepath, monitor="val_accuracy"):
        super().__init__()
        self.filepath = filepath
        self.monitor  = monitor
        self.best     = -np.Inf

    def on_epoch_end(self, epoch, logs=None):
        current = logs.get(self.monitor)
        if current is None:
            return
        # 성능이 개선되었으면 저장
        if current > self.best:
            self.best = current
            # 옵션 없이 순수하게 네이티브 포맷으로 저장
            self.model.save(self.filepath)
            print(f"\n[Checkpoint] 에폭 {epoch+1}에서 {self.monitor}={current:.4f}로 개선, 저장: {self.filepath}")
            
# ── 3) 사용 예 ─────────────────────────────────────────
if __name__ == "__main__":
    APEX_DIR  = "/home/bcml1/sigenv/_7월/face_micro/restart1_apex8/apex_segments_30frame"
    LABEL_DIR = "/home/bcml1/2025_EMOTION/DEAP_5labels"

    # train/val split (파일 기준)
    all_files = sorted(glob.glob(os.path.join(APEX_DIR, "*.npz")))
    all_files = [f for f in all_files if get_label(f, LABEL_DIR) != 4]
    tr_files, vl_files = train_test_split(all_files, test_size=0.2, random_state=42)

    # 한 번에 로드
    X_train, y_train = load_all_data(tr_files, LABEL_DIR)
    X_val,   y_val   = load_all_data(vl_files, LABEL_DIR)
    print('Original samples:', X_train.shape[0])
    
    # 원본 데이터셋
    base_ds = tf.data.Dataset.from_tensor_slices((X_train, y_train))
    # 증강 데이터셋 생성
    # aug_ds = base_ds.map(augment, num_parallel_calls=tf.data.AUTOTUNE)
    aug_ds = base_ds.map(augment, tf.data.AUTOTUNE)
    all_aug = aug_ds.shuffle(1000).repeat(AUGMENT_TIMES)
    full_ds = base_ds.concatenate(all_aug).shuffle(1000)
    train_ds = full_ds.batch(BATCH_SIZE).prefetch(tf.data.AUTOTUNE)
    print('Total train samples:', X_train.shape[0]*(AUGMENT_TIMES+1))
    print('Training batches:', tf.data.experimental.cardinality(train_ds).numpy())

    # 검증 데이터셋
    val_ds = tf.data.Dataset.from_tensor_slices((X_val, y_val)) \
             .batch(BATCH_SIZE).prefetch(tf.data.AUTOTUNE)

    # 모델 빌드
    model = build_microexp3dstcnn(input_shape=(90,64,64,1), num_classes=4)
    model.summary()

    # 체크포인트 콜백 (RESULT_DIR 안에 저장)
    ckpt_path = os.path.join(RESULT_DIR, "best_microexp3dstcnn.keras")
    # cp_cb = tf.keras.callbacks.ModelCheckpoint(
    #     ckpt_path,
    #     save_best_only=True,
    #     monitor="val_accuracy"
    # )
    cp_cb = NativeKerasCheckpoint(ckpt_path, monitor="val_accuracy")
    
    # y_train 은 (N,) shape 의 정수 레이블 배열
    classes = np.unique(y_train)
    weights = class_weight.compute_class_weight(
        class_weight='balanced',
        classes=classes,
        y=y_train
    )
    class_weights = dict(zip(classes, weights))
    print("Class weights:", class_weights)
    
    # 학습
    history = model.fit(
        train_ds,
        validation_data=val_ds,
        epochs=100,
        callbacks=[cp_cb],
        class_weight=class_weights,
        verbose=1
    )

    # 최종 모델 저장
    final_path = os.path.join(RESULT_DIR, "final_microexp3dstcnn.keras")
    model.save(final_path)
    
    
    
    # ── 4) 학습 완료 후 결과 시각화 ────────────────────────────────
    import matplotlib.pyplot as plt
    from sklearn.metrics import confusion_matrix, classification_report
    import numpy as np

    # 1) Accuracy / Loss Curve
    fig, ax = plt.subplots(1, 2, figsize=(12, 4))
    # Accuracy
    ax[0].plot(history.history['accuracy'], label='train_acc')
    ax[0].plot(history.history['val_accuracy'], label='val_acc')
    ax[0].set_title('Accuracy')
    ax[0].set_xlabel('Epoch')
    ax[0].set_ylabel('Accuracy')
    ax[0].legend()
    # Loss
    ax[1].plot(history.history['loss'], label='train_loss')
    ax[1].plot(history.history['val_loss'], label='val_loss')
    ax[1].set_title('Loss')
    ax[1].set_xlabel('Epoch')
    ax[1].set_ylabel('Loss')
    ax[1].legend()

    plt.tight_layout()
    plt.savefig(os.path.join(RESULT_DIR, 'training_curves.png'))
    plt.show()

    # 2) Confusion Matrix on Validation Set
    #    (val_ds 는 batch 단위로 들어오므로, 전체 예측값/정답을 모아서 계산)
    y_trues = []
    y_preds = []
    for x_batch, y_batch in val_ds:
        preds = model.predict(x_batch, verbose=0)
        y_preds.extend(np.argmax(preds, axis=1))
        y_trues.extend(y_batch.numpy())

    cm = confusion_matrix(y_trues, y_preds)
    plt.figure(figsize=(6, 6))
    plt.imshow(cm)
    plt.title('Confusion Matrix')
    plt.xlabel('Predicted Label')
    plt.ylabel('True Label')
    plt.colorbar()
    plt.xticks(range(4))
    plt.yticks(range(4))
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            plt.text(j, i, cm[i, j],
                     ha='center', va='center')
    plt.tight_layout()
    plt.savefig(os.path.join(RESULT_DIR, 'confusion_matrix.png'))
    plt.show()
    
    # 3) Classification Report 저장
    target_names = [f"class_{i}" for i in range(4)]
    report = classification_report(y_trues, y_preds, target_names=target_names, digits=4)
    with open(os.path.join(RESULT_DIR, 'classification_report.txt'), 'w') as f:
        f.write(report)
    print(report)
    
    # print(f"✅ Checkpoints & final model saved to {RESULT_DIR}")
    print("✅ augmentation 적용 학습 완료")
