import os
import sys
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Concatenate, Multiply, Flatten, Lambda, MultiHeadAttention
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping
from tensorflow.keras.utils import register_keras_serializable
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import re
from collections import defaultdict

from sklearn.metrics import accuracy_score
import copy
import os
import numpy as np
from EMCSP_1D_CNN_diff import EEGDataLoader  # 위에 주신 CSP 코드가 이 모듈에 정의되어 있다고 가정
from sklearn.model_selection import train_test_split
#__raw EEG 부분__________________________________
# 설정
RAW_FOLDER   = "/home/bcml1/2025_EMOTION/DEAP_eeg_npy_files"
NUM_SUBJECTS = 20
WINDOW_LEN   = 128  # 예: 600
MODE         = 'inter'      # 혹은 'inter'
LEAVE_OUT    = 11         # inter 모드일 때 제외할 subject 번호
TEST_SIZE    = 0.2
RANDOM_SEED  = 42


# ───────────────────────────────────────────────────────────────
# 설정: 경로 및 하이퍼파라미터
# ───────────────────────────────────────────────────────────────
BASE_DIR       = "/home/bcml1/sigenv/_7월/multimodal_livetime"
EYE_DIR        = os.path.join(BASE_DIR, "features_imp")
FACE_DIR       = os.path.join(BASE_DIR, "face_features")
MOUTH_DIR      = "/home/bcml1/yigeon06/Mouth/feature_1s_segment"
RPPG_DIR       = os.path.join(BASE_DIR, "rppg_features")
# EEG_DIR        = "/home/bcml1/2025_EMOTION/DEAP_eeg_new_label_CSP"
LABEL_ROOT     = "/home/bcml1/2025_EMOTION/DEAP_5labels"
RESULT_DIR     = "/home/bcml1/sigenv/_7월/multimodal_livetime/multi_attention_eeg_cnn"

SEG_LEN_EYE    = 1
SEG_LEN_FACE   = 1
SEG_LEN_MOUTH  = 1
SEG_LEN_RPPG   = 50
WINDOW_LEN_EEG = 128
TEST_RATIO     = 0.2
BATCH_SIZE     = 16
EPOCHS         = 100
NUM_SUBJ       = 20
NUM_TRIAL      = 40

os.makedirs(RESULT_DIR, exist_ok=True)

@register_keras_serializable(package='custom_layers')
class SplitModality(tf.keras.layers.Layer):
    def __init__(self, idx, **kwargs):
        super().__init__(**kwargs)
        self.idx = idx
    def call(self, inputs):
        return tf.expand_dims(inputs[:, self.idx], -1)
    def get_config(self):
        config = super().get_config()
        config.update({'idx': self.idx})
        return config
    @classmethod
    def from_config(cls, config):
        return cls(**config)

# ───────────────────────────────────────────────────────────────
# EEG 세그먼트 로드: (channels, timestamps, filters) -> 윈도우별 (WINDOW_LEN_EEG, channels*filters)
# ───────────────────────────────────────────────────────────────
# def prepare_eeg_segments(eeg_dir, label_root, window_len):
#     import os, re, numpy as np
#     from EMCSP_1D_CNN_diff import EEGDataLoader, EMCSP_EEG_1DCNN_Encoder

#     # 1) raw signals 불러와서 세션 리스트 구성
#     sessions = []
#     for subj in range(1, NUM_SUBJ+1):
#         sid = f"s{subj:02d}"
#         raw_path = os.path.join(eeg_dir, f"{sid}_signals.npy")
#         label_path = os.path.join(label_root, f"subject{subj:02d}.npy")
#         if not os.path.isfile(raw_path) or not os.path.isfile(label_path):
#             continue

#         data = np.load(raw_path)           # shape: (40 trials, 32 channels, T timestamps)
#         labels = np.load(label_path)       # shape: (40,)
#         for ti in range(data.shape[0]):
#             lbl = int(labels[ti])
#             if lbl == 4:                   # Neutral 제외
#                 continue
#             sessions.append({
#                 'subject': sid,
#                 'session': ti+1,
#                 'data':    data[ti],       # (32, T)
#                 'label':   lbl
#             })

#     # 2) 세션 → 윈도우 분할 (직접 구현해서 segment index 확보)
#     raw_trials = []
#     for sess in sessions:
#         subj, trial, X_full, lbl = sess['subject'], sess['session'], sess['data'], sess['label']
#         C, T = X_full.shape
#         for seg_idx, start in enumerate(range(0, T - window_len + 1, window_len)):
#             window = X_full[:, start:start+window_len]
#             raw_trials.append({
#                 'subject': subj,
#                 'session': trial,
#                 'data':    window,
#                 'label':   lbl,
#                 'segment': seg_idx      # ← 여기에 segment index 저장
#             })
#     if not raw_trials:
#         return np.empty((0,window_len,0)), np.array([],dtype=int), []

#     # 3) CSP 계산 & 추출
#     n_ch = raw_trials[0]['data'].shape[0]
#     csp_enc = EMCSP_EEG_1DCNN_Encoder(fs=200,
#                                      window_len=window_len,
#                                      n_channels=n_ch)
#     csp_enc.compute_filters_from_trials(raw_trials)
#     X_raw, y = csp_enc.extract_features_from_trials(raw_trials)

#     # 4) reshape
#     N, nb, wl, nc = X_raw.shape
#     X = X_raw.transpose(0,2,1,3).reshape(N, wl, nb*nc)

#     # 5) 메타 정보 (이제 올바릅니다)
#     meta = [(t['subject'], t['session'], t['segment']) for t in raw_trials]
 
#     return X, np.array(y, dtype=int), meta

def prepare_eeg_segments(eeg_dir, label_root, window_len):
    """
    RAW_FOLDER 내 sXX_signals.npy(40,32,T)와
    LABEL_ROOT 내 subjectXX.npy(40,)를 읽어
    label!=4 인 trial들만 1초 단위(128샘플)로 분할
    → X: (N,128,32) 배열,
      y: (N,) 레이블,
      meta: [(sid,trial_idx,segment_idx),...]
    """
    X, y, meta = [], [], []
    seg_counts = defaultdict(int)

    # 1) raw signals → sessions
    sessions = []
    for subj in range(1, NUM_SUBJ+1):
        sid = f"s{subj:02d}"
        raw_path   = os.path.join(eeg_dir, f"{sid}_signals.npy")
        label_path = os.path.join(label_root, f"subject{subj:02d}.npy")
        if not os.path.isfile(raw_path) or not os.path.isfile(label_path):
            continue

        data   = np.load(raw_path)    # (40 trials,32 ch,T)
        labels = np.load(label_path)  # (40,)
        for ti in range(data.shape[0]):
            lbl = int(labels[ti])
            if lbl == 4:              # Neutral 제외
                continue
            sessions.append({
                'subject': sid,
                'session': ti+1,
                'data':    data[ti],
                'label':   lbl
            })

    # 2) 세션 → 윈도우 분할(앞 3초 스킵)
    raw_trials = []
    for sess in sessions:
        subj, trial, X_full, lbl = sess['subject'], sess['session'], sess['data'], sess['label']
        C, T = X_full.shape
        for seg_idx, start in enumerate(range(3*window_len, T - window_len + 1, window_len)):
            window = X_full[:, start:start+window_len]
            raw_trials.append({
                'subject': subj,
                'session': trial,
                'data':    window,
                'label':   lbl,
                'segment': seg_idx
            })
            seg_counts[lbl] += 1

    if not raw_trials:
        return np.empty((0,window_len,0)), np.array([],dtype=int), []

    # 3) CSP 계산 & 추출
    n_ch = raw_trials[0]['data'].shape[0]
    from EMCSP_1D_CNN_diff import EMCSP_EEG_1DCNN_Encoder
    csp_enc = EMCSP_EEG_1DCNN_Encoder(fs=200,
                                     window_len=window_len,
                                     n_channels=n_ch)
    csp_enc.compute_filters_from_trials(raw_trials)
    X_raw, y = csp_enc.extract_features_from_trials(raw_trials)

    # 4) reshape
    N, nb, wl, nc = X_raw.shape
    X = X_raw.transpose(0,2,1,3).reshape(N, wl, nb*nc)

    # 5) meta
    meta = [(t['subject'], t['session'], t['segment'])
            for t in raw_trials]

    # ── 디버그: 0~3 레이블별 세그먼트 개수 출력 ──
    print(">> [EEG] loaded segments per label:")
    for lbl in range(4):
        print(f"   label {lbl}: {seg_counts.get(lbl, 0)}")
    print("──────────────────────────────────────")

    return X, np.array(y, dtype=int), meta
# ───────────────────────────────────────────────────────────────
# 기존 모달리티 로드 (변경 없음)
# ───────────────────────────────────────────────────────────────
def prepare_segments(base_dir, label_root, seg_len, is_rppg=False):
    X, y, meta = [], [], []
    for subj in range(1, NUM_SUBJ+1):
        sid = f"s{subj:02d}"
        label_file = os.path.join(label_root, f"subject{subj:02d}.npy")
        if not os.path.isfile(label_file): continue
        labels = np.load(label_file)
        subj_dir = os.path.join(base_dir, sid)
        if not os.path.isdir(subj_dir):
            if 'Mouth' in base_dir:
                subj_dir = base_dir
            else:
                continue
        for fname in sorted(os.listdir(subj_dir)):
            if not fname.endswith('.npy'): continue
            if is_rppg:
                m = re.match(r"trial(\d{2})_csp_rppg_multiclass\.npy", fname)
            elif 'Mouth' in base_dir and sid in fname:
                m = re.match(rf"{sid}_trial(\d{{2}})_features\.npy", fname)
            else:
                m = re.match(rf"{sid}_trial(\d{{2}})\.npy", fname)
            if not m: continue
            trial_idx = int(m.group(1))
            label = int(labels[trial_idx-1])
            if label == 4: continue
            data = np.load(os.path.join(subj_dir, fname))
            length = data.shape[1]
            for i in range(0, length, seg_len):
                j = i + seg_len
                if j > length: break
                seg = data[:, i:j]
                if seg.shape[1] != seg_len: continue
                X.append(seg.T)
                y.append(label)
                meta.append((sid, trial_idx, i//seg_len))
    if not X:
        return np.empty((0, seg_len, 0)), np.array([], dtype=int), []
    return np.stack(X, axis=0), np.array(y, dtype=int), meta

if __name__ == '__main__':
    # 1) Load segments
    X_eye,  y_eye,  meta_eye  = prepare_segments(EYE_DIR,  LABEL_ROOT, SEG_LEN_EYE, False)
    X_face, y_face, meta_face = prepare_segments(FACE_DIR, LABEL_ROOT, SEG_LEN_FACE, False)
    X_mouth,y_mouth,meta_mouth= prepare_segments(MOUTH_DIR,LABEL_ROOT,SEG_LEN_MOUTH, False)
    X_rppg, y_rppg, meta_rppg = prepare_segments(RPPG_DIR, LABEL_ROOT, SEG_LEN_RPPG, True)
    X_eeg,  y_eeg,  meta_eeg  = prepare_eeg_segments(RAW_FOLDER, LABEL_ROOT, WINDOW_LEN_EEG)
    # --- Debug: count segments per subject for each modality ---
    def print_subject_counts(name, meta):
        counts = defaultdict(int)
        for subj, trial, start in meta:
            counts[subj] += 1
        print(f">>> {name} segments per subject:")
        for subj in sorted(counts):
            print(f"    {subj}: {counts[subj]}")
        print()

    print_subject_counts("Eye",   meta_eye)
    print_subject_counts("Face",  meta_face)
    print_subject_counts("Mouth", meta_mouth)
    print_subject_counts("rPPG",  meta_rppg)
    print_subject_counts("EEG",   meta_eeg)
    # 2) Validate existence
    for name, arr in [('Eye',X_eye),('Face',X_face),('Mouth',X_mouth),('rPPG',X_rppg),('EEG',X_eeg)]:
        if arr.size == 0:
            raise FileNotFoundError(f"{name} features empty")

    # 3) Align common meta
    set_eye = set(meta_eye)
    common = set_eye & set(meta_face) & set(meta_mouth) & set(meta_rppg) & set(meta_eeg)
    ordered = [m for m in meta_eye if m in common]
    idx_map = lambda ml: [ml.index(m) for m in ordered]
    ix_e, ix_f, ix_m, ix_r, ix_q = map(idx_map, (meta_eye, meta_face, meta_mouth, meta_rppg, meta_eeg))
    X_eye, X_face, X_mouth, X_rppg, X_eeg, y = (
        X_eye[ix_e], X_face[ix_f], X_mouth[ix_m], X_rppg[ix_r], X_eeg[ix_q], y_eye[ix_e]
    )
    # ── 디버그 #1: alignment 후 라벨 분포 확인 ──
    unique, counts = np.unique(y, return_counts=True)
    print("Labels after alignment:", dict(zip(unique, counts)))

    # 4) Remap labels
    classes = np.unique(y)
    print("Unique classes:", classes)
    cmap = {c: i for i, c in enumerate(classes)}
    y = np.array([cmap[v] for v in y], dtype=int)
    num_classes = len(classes)

    # 5) Normalize
    def normalize(X):
        flat = X.reshape(-1, X.shape[-1])
        mean = np.nanmean(flat, axis=0)
        std = np.nanstd(flat, axis=0) + 1e-6
        return (X - mean) / std

    X_eye   = normalize(X_eye)
    X_face  = normalize(X_face)
    X_mouth = normalize(X_mouth)
    X_rppg  = normalize(X_rppg)
    X_eeg   = normalize(X_eeg)

    # 6) Replace NaN/Inf in EEG (and other modalities) with zero, no segment drop
    X_eeg   = np.nan_to_num(X_eeg,   nan=0.0, posinf=0.0, neginf=0.0)
    X_eye   = np.nan_to_num(X_eye,   nan=0.0, posinf=0.0, neginf=0.0)
    X_face  = np.nan_to_num(X_face,  nan=0.0, posinf=0.0, neginf=0.0)
    X_mouth = np.nan_to_num(X_mouth, nan=0.0, posinf=0.0, neginf=0.0)
    X_rppg  = np.nan_to_num(X_rppg,  nan=0.0, posinf=0.0, neginf=0.0)
      # y는 변함 없음
    
    # 7) Split
    splits = train_test_split(X_eye,X_face,X_mouth,X_rppg,X_eeg,y,
                              test_size=TEST_RATIO, random_state=42, stratify=y)
    Xe_tr,Xe_te,Xf_tr,Xf_te,Xm_tr,Xm_te,Xr_tr,Xr_te,Xq_tr,Xq_te,y_tr,y_te = splits
    
    # ── 디버그 #2: train/test 분포 확인 ──
    ut, ct = np.unique(y_tr, return_counts=True)
    print("Train labels:", dict(zip(ut, ct)))
    ut, ct = np.unique(y_te, return_counts=True)
    print(" Test labels:", dict(zip(ut, ct)))
    single_accs = {}
    from tensorflow.keras.layers import Input, Flatten, Dense
    from tensorflow.keras.models import Model

    def train_single_modal(X_tr, X_te, name):
        inp = Input(shape=X_tr.shape[1:], name=f"{name}_in")          
        x   = Flatten()(inp)
        x   = Dense(128, activation='relu')(x)
        out = Dense(num_classes, activation='softmax')(x)
        m   = Model(inp, out, name=f"{name}_single")
        m.compile(optimizer='adam',
                loss='sparse_categorical_crossentropy',
                metrics=['accuracy'])
        # 10 epochs 정도면 충분합니다
        m.fit(X_tr, y_tr,
            validation_data=(X_te, y_te),
            epochs=10,
            batch_size=BATCH_SIZE,
            verbose=2)
        _, acc = m.evaluate(X_te, y_te, verbose=0)
        print(f"{name} single accuracy = {acc:.4f}")
        return acc

    # ─── 여기서 각 모달리티별 단일-모달 정확도 계산 ───
    single_accs['eye']   = train_single_modal(Xe_tr, Xe_te, 'eye')
    single_accs['face']  = train_single_modal(Xf_tr, Xf_te, 'face')
    single_accs['mouth'] = train_single_modal(Xm_tr, Xm_te, 'mouth')
    single_accs['rppg']  = train_single_modal(Xr_tr, Xr_te, 'rppg')
    single_accs['eeg']   = train_single_modal(Xq_tr, Xq_te, 'eeg')

    # ─── 정확도를 합 1로 정규화해 가중치로 변환 ───
    import tensorflow.keras.backend as K
    weights = np.array([single_accs[m] for m in ['eye','face','mouth','rppg','eeg']])
    weights = weights / weights.sum()           # shape (5,)
    print("Gating weights:", weights)
    # 배치×모달×1 형태 텐서로 만들어 둡니다
    weight_tensor = K.constant(weights.reshape(1,5,1), dtype=tf.float32)

    # 8) Load extractors
    from Eye_model   import build_eye_model
    from Face_model  import build_face_model
    from Mouth_model import build_mouth_model
    # [EEG CNN extractor]
    from tensorflow.keras.layers import Conv1D, MaxPooling1D, GlobalAveragePooling1D, BatchNormalization, Flatten
    def build_eeg_cnn(seq_len, feat_dim, embed_dim):
        inp = Input((seq_len, feat_dim), name='eeg_cnn_in')
        x = Conv1D(64, 7, activation='relu', padding='same')(inp)
        x = BatchNormalization()(x)
        x = MaxPooling1D(2)(x)
        x = GlobalAveragePooling1D()(x)
        x = Dense(embed_dim, activation='relu')(x)
        return Model(inp, x, name='eeg_extractor')

    eye_base   = build_eye_model(num_classes, SEG_LEN_EYE, Xe_tr.shape[2])
    # Load eye extractor weights
    eye_base.load_weights(
        os.path.join(BASE_DIR,'eye_model','best_eye.weights.h5'),
        by_name=True,
        skip_mismatch=True
    )
    
    face_base  = build_face_model(num_classes, SEG_LEN_FACE, Xf_tr.shape[2])
    # Load face extractor weights
    face_base.load_weights(
        os.path.join(BASE_DIR,'face_model','best_face.weights.h5'),
        by_name=True,
        skip_mismatch=True
    )
    
    mouth_base = build_mouth_model(num_classes, SEG_LEN_MOUTH, Xm_tr.shape[2])

    embed_dim = eye_base.layers[-2].output_shape[-1]
    eeg_base  = build_eeg_cnn(WINDOW_LEN_EEG, Xq_tr.shape[2], embed_dim)

    eye_ext   = Model(eye_base.input,   eye_base.layers[-2].output)
    face_ext  = Model(face_base.input,  face_base.layers[-2].output)
    mouth_ext = Model(mouth_base.input, mouth_base.layers[-2].output)
    eeg_ext   = Model(eeg_base.input,   eeg_base.output)
    for ext in (eye_ext, face_ext, mouth_ext, eeg_ext): ext.trainable=True
    
    from tensorflow.keras.layers import MultiHeadAttention, Lambda
    # --- 하이퍼파라미터 ---
    pdim          = embed_dim   # 기존에 정의하신 embedding 차원
    num_classes   = num_classes
    SEG_LEN_EEG   = WINDOW_LEN
    EEG_FEAT_DIM  = Xq_tr.shape[2]  # 예: 4 bands × 8 components = 32

    # --- rPPG 브랜치 (변경 없음) ---
    in_r = Input((SEG_LEN_RPPG, Xr_tr.shape[2]), name='rppg_input')
    pr   = Flatten(name='rppg_flat')(in_r)
    feat_r = Dense(pdim, activation='relu', name='rppg_proj')(pr)

    # --- 기존 모달리티들 (eye_ext, face_ext, mouth_ext 는 freeze된 extractor) ---
    in_e = Input((SEG_LEN_EYE, Xe_tr.shape[2]),  name='eye_input')
    in_f = Input((SEG_LEN_FACE, Xf_tr.shape[2]), name='face_input')
    in_m = Input((SEG_LEN_MOUTH, Xm_tr.shape[2]),name='mouth_input')
    fe  = eye_ext(in_e)    # (batch, pdim)
    ff  = face_ext(in_f)   # (batch, pdim)
    fm  = mouth_ext(in_m)  # (batch, pdim)

    # --- EEG 브랜치 (raw→CSP→flatten→Dense) ---
    in_q = Input((SEG_LEN_EEG, EEG_FEAT_DIM), name='eeg_input')
    qf   = Flatten(name='eeg_flat')(in_q)
    feat_q = Dense(pdim, activation='relu', name='eeg_proj')(qf)  # (batch, pdim)

    # --- 모달리티 스택 & 셀프-어텐션 ---
    modal_stack = Lambda(lambda tensors: tf.stack(tensors, axis=1),
                        name='modal_stack')([fe, ff, fm, feat_r, feat_q])
    
    from tensorflow.keras.layers import Dense, Activation, Multiply, LayerNormalization, GaussianNoise, Dropout
    from tensorflow.keras.layers import MultiHeadAttention, Flatten, Lambda
    # attn_output = MultiHeadAttention(
    #     num_heads=1, key_dim=pdim, name='modal_self_attention'
    # )(
    #     query=modal_stack, value=modal_stack, key=modal_stack
    # )  # (batch, 5, pdim)
    # ─── (B) 단일-모달 정확도 기반 게이팅 적용 ───
    # 1) 정규화 + 노이즈
    x = LayerNormalization(name='modal_norm')(modal_stack)
    x = GaussianNoise(0.1, name='modal_noise')(x)

    # 2) 학습 가능한 게이팅
    g = Flatten(name='gating_flat')(x)                     # (batch, 5*pdim)
    g = Dense(5, name='gating_logits')(g)                  # (batch,5)
    g = Activation('softmax', name='gating_weights')(g)    # (batch,5)
    g = Lambda(lambda w: tf.expand_dims(w, -1), name='gating_expand')(g)  # (batch,5,1)
    gated = Multiply(name='gated_stack')([x, g])           # (batch,5,pdim)

    # 3) Modality Dropout (batch × 5 × pdim) → 확률적으로 모달 하나씩 끄기
    
    def mod_dropout(x, p=0.3):
        shape = tf.shape(x)
        batch_size = shape[0]
        num_modal  = shape[1]
        # (batch, num_modal, 1) 으로 mask 생성
        mask = tf.cast(
            tf.random.uniform((batch_size, num_modal, 1)) > p,
            x.dtype
        )
        return x * mask

    # Lambda 부분도 아래처럼 교체
    gated = Lambda(lambda t: mod_dropout(t, p=0.3),
                name='modality_dropout')(gated)
    # 4) Multi-Head Attention (2 heads, key_dim = pdim//2)
    attn_out = MultiHeadAttention(
        num_heads=2,
        key_dim=pdim//2,
        name='modal_self_attention'
    )(
        query=gated, value=gated, key=gated
    )  # (batch,5,pdim)

    # 5) 풀링 → 분류기 헤드 (이전과 동일)
    fused = Lambda(lambda x: tf.reduce_mean(x, axis=1), name='fused')(attn_out)
    x = Dense(128, activation='relu', name='fusion_dense')(fused)
    out = Dense(num_classes, activation='softmax', name='out')(x)
    # --- 모델 컴파일 ---
    model = Model(inputs=[in_e, in_f, in_m, in_r, in_q], outputs=out,
                name='attn_multimodal_eeg_rawcsp')
    model.compile(optimizer='adam',
                loss='sparse_categorical_crossentropy',
                metrics=['accuracy'])
    model.summary()
    # 9) Train
    cp = ModelCheckpoint(
        os.path.join(RESULT_DIR, 'best_model.weights.h5'),
        save_best_only=True,
        monitor='val_accuracy',
        save_weights_only=True   # ← 전체 모델이 아니라 가중치만 저장
    )

    hist = model.fit([Xe_tr, Xf_tr, Xm_tr, Xr_tr, Xq_tr], y_tr,
                     validation_split=0.2, epochs=EPOCHS,
                     batch_size=BATCH_SIZE, callbacks=[cp], verbose=2)
    model.save(os.path.join(RESULT_DIR, 'final_model.keras'))


    # 10) Evaluate & Save
    loss, acc = model.evaluate([Xe_te, Xf_te, Xm_te, Xr_te, Xq_te], y_te, verbose=2)
    print(f"Test loss={loss:.4f}, acc={acc:.4f}")
    pred = model.predict([Xe_te, Xf_te, Xm_te, Xr_te, Xq_te]).argmax(1)
    rep  = classification_report(y_te, pred)
    cm   = confusion_matrix(y_te, pred)
    with open(os.path.join(RESULT_DIR,'report.txt'),'w') as f: f.write(rep)
    np.savetxt(os.path.join(RESULT_DIR,'cm.txt'), cm, fmt='%d')
    plt.figure();plt.plot(hist.history['loss'],label='loss');plt.plot(hist.history['val_loss'],label='val_loss');plt.legend();plt.savefig(os.path.join(RESULT_DIR,'loss.png'))
    plt.figure();plt.plot(hist.history['accuracy'],label='acc');plt.plot(hist.history['val_accuracy'],label='val_acc');plt.legend();plt.savefig(os.path.join(RESULT_DIR,'acc.png'))

        
    # 1) 원본 정확도 계산
    y_pred_orig = model.predict([Xe_te, Xf_te, Xm_te, Xr_te, Xq_te]).argmax(axis=1)
    base_acc = accuracy_score(y_te, y_pred_orig)
    print(f"Base accuracy: {base_acc:.4f}")
    
    # 2) 퍼뮤테이션 중요도 함수 정의
    def permutation_importance(model, X_list, y_true, idx):
        X_list_perm = [x.copy() for x in X_list]
        # idx번째 모달(batch x time x feat) 차원 중 batch 축만 셔플
        np.random.shuffle(X_list_perm[idx])
        y_pred = model.predict(X_list_perm).argmax(axis=1)
        return base_acc - accuracy_score(y_true, y_pred)
    
    # 3) 각 모달 이름 및 데이터 리스트 준비
    modal_names = ['eye', 'face', 'mouth', 'rppg', 'eeg']
    X_list = [Xe_te, Xf_te, Xm_te, Xr_te, Xq_te]
    
    # 4) 중요도 계산 및 출력
    for i, name in enumerate(modal_names):
        delta = permutation_importance(model, X_list, y_te, i)
        print(f"{name:6} importance drop: {delta:.4f}")
