import os, sys
import numpy as np
import tensorflow as tf
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt

# 모듈 탐색 경로 추가
sys.path.append(os.path.dirname(os.path.realpath(__file__)))
from EYE_feature import extract_features_from_video
from Eye_model import build_eye_model

# ───────────────────────────────────────────────────────────────
# 0) 경로 및 설정
# ───────────────────────────────────────────────────────────────
VIDEO_ROOT     = "/home/bcml1/2025_EMOTION/face_video"
LABEL_ROOT     = "/home/bcml1/2025_EMOTION/DEAP_5labels"
FEATURE_DIR    = "features_10s"         # feature 저장 디렉토리
RESULT_DIR     = "results3_10s"
NUM_SUBJECTS   = 22
NUM_SAMPLES    = 40
START_SUBJECT  = 1                      # 저장을 시작할 subject 번호

BATCH_SIZE     = 8
EPOCHS         = 200

# 모드 설정: True로 두면 feature 추출 후 저장만 수행
SAVE_FEATURES  = False

os.makedirs(RESULT_DIR, exist_ok=True)
os.makedirs(FEATURE_DIR, exist_ok=True)

# ───────────────────────────────────────────────────────────────
# 기능 1: 모든 비디오에서 feature 추출 및 저장 (특정 subject부터 이어서)
# ───────────────────────────────────────────────────────────────
def save_all_features(video_root, feature_dir, num_subj, num_samp, start_subj=1):
    for subj in range(start_subj, num_subj+1):
        subj_id = f"s{subj:02d}"
        out_dir = os.path.join(feature_dir, subj_id)
        os.makedirs(out_dir, exist_ok=True)
        for trial in range(1, num_samp+1):
            vid_fname = f"{subj_id}_trial{trial:02d}.avi"
            vid_path  = os.path.join(video_root, subj_id, vid_fname)
            if not os.path.isfile(vid_path):
                print(f"Warning: missing {vid_path}, skipping")
                continue
            feats, _ = extract_features_from_video(vid_path)
            if feats.size == 0:
                print(f"Warning: no features for {vid_path}, skipping")
                continue
            save_path = os.path.join(out_dir, f"{subj_id}_trial{trial:02d}.npy")
            np.save(save_path, feats)
            print(f"Saved features to {save_path}")
    print("All features saved.")

# ───────────────────────────────────────────────────────────────
# 기능 2: 저장된 feature 불러와서 segment별 데이터 준비
# ───────────────────────────────────────────────────────────────
def prepare_segments_from_saved(feature_dir, label_root, num_subj, num_samp):
    X_list, y_list, meta = [], [], []
    for subj in range(1, num_subj+1):
        subj_id    = f"s{subj:02d}"
        label_path = os.path.join(label_root, f"subject{subj:02d}.npy")
        if not os.path.isfile(label_path):
            raise FileNotFoundError(label_path)
        subj_labels = np.load(label_path)
        for trial in range(1, num_samp+1):
            feat_file = os.path.join(feature_dir, subj_id, f"{subj_id}_trial{trial:02d}.npy")
            if not os.path.isfile(feat_file):
                print(f"Warning: missing feature {feat_file}, skipping")
                continue
            feats = np.load(feat_file)
            label = int(subj_labels[trial-1])
            n_seg  = feats.shape[1]
            for seg in range(n_seg):
                vec = feats[:, seg]
                X_list.append(vec)
                y_list.append(label)
                meta.append((subj, trial, seg))
    X = np.stack(X_list, axis=0)
    X = X[:, None, :]
    y = np.array(y_list, dtype=np.int32)
    return X, y, meta

# ───────────────────────────────────────────────────────────────
# main 실행부
# ───────────────────────────────────────────────────────────────
if __name__ == '__main__':
    if SAVE_FEATURES:
        # feature 추출 및 저장만 수행 (START_SUBJECT부터)
        save_all_features(VIDEO_ROOT, FEATURE_DIR, NUM_SUBJECTS, NUM_SAMPLES, START_SUBJECT)
        sys.exit(0)

    
    # ───────────────────────────────────────────────────────────────
    # 1) 저장된 feature 로부터 데이터 준비
    # ───────────────────────────────────────────────────────────────
    X, y, meta = prepare_segments_from_saved(
        FEATURE_DIR,
        LABEL_ROOT,
        NUM_SUBJECTS,
        NUM_SAMPLES
    )
    print(f"Collected segments: {X.shape}, labels: {y.shape}")

    # ───────────────────────────────────────────────────────────────
    # 2) 라벨 4 제외 (0~3만 사용)
    # ───────────────────────────────────────────────────────────────
    mask_keep = (y != 4)
    num_drop = np.sum(~mask_keep)
    if num_drop > 0:
        print(f"Dropping {num_drop} segments with label 4")
    X = X[mask_keep]
    y = y[mask_keep]
    meta = [m for idx, m in enumerate(meta) if mask_keep[idx]]

    print(f"After excluding label 4: {X.shape}, {y.shape}")

    # ───────────────────────────────────────────────────────────────
    # 3) label map 생성 및 나머지 파이프라인 그대로
    # ───────────────────────────────────────────────────────────────
    unique_labels = np.unique(y)
    label_map     = {lab: idx for idx, lab in enumerate(unique_labels)}
    y = np.array([label_map[lab] for lab in y], dtype=np.int32)
    NUM_CLASSES   = len(unique_labels)
    print(f"Label mapping: {label_map}")
    print(f"New y unique: {np.unique(y)}, NUM_CLASSES: {NUM_CLASSES}")


    # NaN/Inf 제거
    mask = ~np.isnan(X).any(axis=(1,2)) & ~np.isinf(X).any(axis=(1,2))
    if not mask.all():
        print(f"Dropping {mask.size-mask.sum()} bad segments")
        X, y = X[mask], y[mask]
    print(f"After clean: {X.shape}, {y.shape}")

    # 정규화
    N, _, D = X.shape
    Xf = X.reshape(N, D)
    m  = Xf.mean(0, keepdims=True)
    s  = Xf.std(0, keepdims=True) + 1e-6
    X  = ((Xf - m)/s).reshape(N, 1, D)

    # train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=0.2,
        random_state=42,
        stratify=y
    )

    # 모델 빌드·컴파일
    model = build_eye_model(
        num_classes=NUM_CLASSES,
        seq_length=X_train.shape[1],
        feature_dim=X_train.shape[2]
    )
    model.compile(
        optimizer=tf.keras.optimizers.Adam(1e-4),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"]
    )

    # 콜백 정의
    cp = ModelCheckpoint(
        os.path.join(RESULT_DIR, "best_eye_model.keras"),
        monitor="val_accuracy", save_best_only=True, verbose=1
    )
    es = EarlyStopping(
        monitor="val_loss", patience=10, restore_best_weights=True, verbose=1
    )

    # 학습
    history = model.fit(
        X_train, y_train,
        validation_split=0.2,
        epochs=EPOCHS,
        batch_size=BATCH_SIZE,
        callbacks=[cp, es],
        verbose=2
    )

    # 평가 & 리포트 저장
    loss, acc = model.evaluate(X_test, y_test, verbose=2)
    print(f"Test Loss: {loss:.4f}, Acc: {acc:.4f}")

    y_pred = model.predict(X_test).argmax(axis=1)
    labels = np.unique(np.concatenate([y_test, y_pred]))
    report = classification_report(
        y_test, y_pred,
        labels=labels.tolist(),
        target_names=[str(l) for l in labels]
    )
    cm = confusion_matrix(y_test, y_pred, labels=labels)
    print(report)
    print("Confusion matrix:")
    print(cm)

    # 결과 저장
    with open(os.path.join(RESULT_DIR, "classification_report.txt"), "w") as f:
        f.write(report)
    np.savetxt(
        os.path.join(RESULT_DIR, "confusion_matrix.txt"),
        cm, fmt="%d"
    )
    # Loss & Accuracy curve 저장
    plt.figure(); plt.plot(history.history["loss"], label="Train Loss"); plt.plot(history.history["val_loss"], label="Val Loss"); plt.legend(); plt.title("Loss Curve"); plt.savefig(os.path.join(RESULT_DIR, "loss_curve.png")); plt.close()
    plt.figure(); plt.plot(history.history["accuracy"], label="Train Acc"); plt.plot(history.history["val_accuracy"], label="Val Acc"); plt.legend(); plt.title("Accuracy Curve"); plt.savefig(os.path.join(RESULT_DIR, "accuracy_curve.png")); plt.close()
