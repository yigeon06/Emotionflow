import os
import cv2
import numpy as np
import mediapipe as mp

# --- Configuration ---
VIDEO_ROOT           = "/home/bcml1/2025_EMOTION/face_video"
OUTPUT_ROOT          = "/home/bcml1/2025_EMOTION/face_aligned_npy_30fps"
SUBJECT_COUNT        = 22
TRIAL_COUNT          = 40
OUT_SIZE             = 112   # 출력 크기
PAD                  = 20    # 크롭 박스 여유 영역
BRIGHTNESS_THRESHOLD = 40    # 밝기 기준
N_LM                 = 478   # FaceMesh refine_landmarks=True 시 반환 포인트 수

os.makedirs(OUTPUT_ROOT, exist_ok=True)

# MediaPipe Face Mesh: streaming 모드
mp_face = mp.solutions.face_mesh.FaceMesh(
    static_image_mode=False,    # 연속 프레임은 tracking
    refine_landmarks=True,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

# CLAHE & Bilateral 필터
clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))

# 전역 마지막 유효 bbox
last_bbox = None

def detect_and_align_with_flag(frame):
    """얼굴 탐지→보정→회전→크롭. 실패 시 aligned, detected, lm_arr 반환."""
    global last_bbox
    h, w = frame.shape[:2]
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # 1) 탐지
    res = mp_face.process(rgb)
    detected = bool(res.multi_face_landmarks)
    if not detected:
        # 2) 보정 후 재시도
        lab = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        cl = clahe.apply(l)
        merged = cv2.merge((cl, a, b))
        frame = cv2.cvtColor(merged, cv2.COLOR_LAB2BGR)
        frame = cv2.bilateralFilter(frame, 5, 75, 75)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        res = mp_face.process(rgb)
        detected = bool(res.multi_face_landmarks)

    # 첫 프레임부터 못 잡고 last_bbox 없으면 버림
    if not detected and last_bbox is None:
        return None, False, None

    # 탐지 실패하지만 이전 bbox 있으면 fallback crop
    if not detected:
        x1, y1, x2, y2 = last_bbox
        crop = frame[y1:y2, x1:x2]
        aligned = cv2.resize(crop, (OUT_SIZE, OUT_SIZE))
        return aligned, False, None

    # 회전 처리
    lm = res.multi_face_landmarks[0].landmark
    left_idxs, right_idxs = [33, 133], [362, 263]
    lp = np.array([[lm[i].x * w, lm[i].y * h] for i in left_idxs])
    rp = np.array([[lm[i].x * w, lm[i].y * h] for i in right_idxs])
    lc, rc = lp.mean(axis=0), rp.mean(axis=0)
    dx, dy = rc - lc
    M = cv2.getRotationMatrix2D(tuple(lc), np.degrees(np.arctan2(dy, dx)), 1.0)
    frame = cv2.warpAffine(frame, M, (w, h), flags=cv2.INTER_LINEAR)

    # 회전 후 재탐지
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    res = mp_face.process(rgb)
    if not bool(res.multi_face_landmarks):
        x1, y1, x2, y2 = last_bbox
        crop = frame[y1:y2, x1:x2]
        aligned = cv2.resize(crop, (OUT_SIZE, OUT_SIZE))
        return aligned, False, None

    # 성공: bbox 크롭 & landmark 생성
    lm = res.multi_face_landmarks[0].landmark
    xs = np.array([p.x * w for p in lm])
    ys = np.array([p.y * h for p in lm])
    x1 = max(0, int(xs.min()) - PAD)
    y1 = max(0, int(ys.min()) - PAD)
    x2 = min(w, int(xs.max()) + PAD)
    y2 = min(h, int(ys.max()) + PAD)
    last_bbox = (x1, y1, x2, y2)

    crop = frame[y1:y2, x1:x2]
    aligned = cv2.resize(crop, (OUT_SIZE, OUT_SIZE))
    if aligned.mean() < BRIGHTNESS_THRESHOLD:
        return aligned, False, None

    lm_arr = np.array([[p.x * w, p.y * h] for p in lm], dtype=np.float32)
    return aligned, True, lm_arr

# 비디오 처리
for subj in range(7, SUBJECT_COUNT + 1):
    sname = f"s{subj:02d}"
    for trial in range(1, TRIAL_COUNT + 1):
        vfile = os.path.join(VIDEO_ROOT, sname, f"{sname}_trial{trial:02d}.avi")
        if not os.path.isfile(vfile):
            print(f"[WARN] Missing {vfile}")
            continue

        cap = cv2.VideoCapture(vfile)
        # ➊ 원본 fps 읽기 (실제 50fps)
        orig_fps = cap.get(cv2.CAP_PROP_FPS)
        if orig_fps <= 0:
            orig_fps = 50  # fallback
        # ➋ 타깃 fps 설정 및 타임스텝 계산
        target_fps = 30
        frame_time = 1.0 / orig_fps
        target_frame_time = 1.0 / target_fps

        # 다운샘플용 타임스탬프 변수
        next_frame_time = 0.0
        frame_idx = 0

        frames = []
        detect_mask = []
        fallback_mask = []
        landmarks = []
        bboxes = []

        last_bbox = None
        while True:
            ret, frame = cap.read()
            if not ret:
                break

            # ➌ 현재 프레임의 시간 (초)
            current_time = frame_idx * frame_time
            frame_idx += 1

            # ➍ 아직 다음 저장 시점이 아니면 스킵
            if current_time < next_frame_time:
                continue
            # ➎ 저장 시점이 되었으면, 다음 시점 계산
            next_frame_time += target_frame_time

            # 얼굴 검출·정렬
            aligned, detected, lm_arr = detect_and_align_with_flag(frame)
            bboxes.append(last_bbox if last_bbox is not None else (np.nan,) * 4)

            if aligned is None:
                frames.append(np.zeros((OUT_SIZE, OUT_SIZE, 3), dtype=np.uint8))
                detect_mask.append(False)
                fallback_mask.append(False)
                landmarks.append(np.full((N_LM, 2), np.nan))
            else:
                frames.append(aligned)
                detect_mask.append(detected)
                fallback_mask.append(not detected)
                landmarks.append(lm_arr if lm_arr is not None 
                                 else np.full((N_LM, 2), np.nan))

        cap.release()

        # 리스트 → 배열
        data = np.stack(frames, axis=0)                  # (T_down, 112,112,3)
        detect_mask   = np.array(detect_mask, dtype=bool)  
        fallback_mask = np.array(fallback_mask, dtype=bool)
        landmarks     = np.stack(landmarks, axis=0)       # (T_down, 478,2)
        bboxes        = np.stack(bboxes, axis=0)          # (T_down,4)

        out_path = os.path.join(OUTPUT_ROOT, f"{sname}_trial{trial:02d}.npz")
        np.savez_compressed(
            out_path,
            data=data,
            detect_mask=detect_mask,
            fallback_mask=fallback_mask,
            landmarks=landmarks,
            bboxes=bboxes
        )

        print(f"[OK] {out_path}: "
              f"frames={data.shape[0]}, "
              f"detect={detect_mask.sum()}, "
              f"fallback={fallback_mask.sum()}")