import os, sys
import numpy as np
import tensorflow as tf
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt

# 모듈 탐색 경로 추가
sys.path.append(os.path.dirname(os.path.realpath(__file__)))
from Face_feature import extract_face_features_from_video
from Face_model import build_face_model

# ───────────────────────────────────────────────────────────────
# 0) 경로 및 설정
# ───────────────────────────────────────────────────────────────
VIDEO_ROOT     = "/home/bcml1/2025_EMOTION/face_video"
LABEL_ROOT     = "/home/bcml1/2025_EMOTION/DEAP_5labels"
FEATURE_DIR    = "face_features"    # 얼굴 feature 저장 디렉토리
RESULT_DIR     = "face_results_2"
NUM_SUBJECTS   = 22
NUM_SAMPLES    = 40
START_SUBJECT  = 1                   # 저장을 시작할 subject 번호

BATCH_SIZE     = 8
EPOCHS         = 500

# 모드 설정: True로 두면 feature 추출 및 저장만 수행
SAVE_FEATURES  = False

os.makedirs(RESULT_DIR, exist_ok=True)
os.makedirs(FEATURE_DIR, exist_ok=True)

# ───────────────────────────────────────────────────────────────
# 기능 1: 모든 비디오에서 feature 추출 및 저장 (특정 subject부터 이어서)
# ───────────────────────────────────────────────────────────────
def save_all_features(video_root, feature_dir, num_subj, num_samp, start_subj=1):
    for subj in range(start_subj, num_subj+1):
        subj_id = f"s{subj:02d}"
        out_dir = os.path.join(feature_dir, subj_id)
        os.makedirs(out_dir, exist_ok=True)
        for trial in range(1, num_samp+1):
            vid_fname = f"{subj_id}_trial{trial:02d}.avi"
            vid_path  = os.path.join(video_root, subj_id, vid_fname)
            if not os.path.isfile(vid_path):
                print(f"Warning: missing {vid_path}, skipping")
                continue
            feats, _ = extract_face_features_from_video(vid_path)
            if feats.size == 0:
                print(f"Warning: no features for {vid_path}, skipping")
                continue
            save_path = os.path.join(out_dir, f"{subj_id}_trial{trial:02d}.npy")
            np.save(save_path, feats)
            print(f"Saved features to {save_path}")
    print("All face features saved.")

# ───────────────────────────────────────────────────────────────
# 기능 2: 저장된 feature 불러와서 segment별 데이터 준비
# ───────────────────────────────────────────────────────────────
def prepare_segments_from_saved(feature_dir, label_root, num_subj, num_samp):
    X_list, y_list, meta = [], [], []
    for subj in range(1, num_subj+1):
        subj_id    = f"s{subj:02d}"
        label_path = os.path.join(label_root, f"subject{subj:02d}.npy")
        subj_labels = np.load(label_path)
        for trial in range(1, num_samp+1):
            feat_file = os.path.join(feature_dir, subj_id, f"{subj_id}_trial{trial:02d}.npy")
            if not os.path.isfile(feat_file):
                continue
            feats = np.load(feat_file)
            label = int(subj_labels[trial-1])
            for seg in range(feats.shape[1]):
                X_list.append(feats[:, seg])
                y_list.append(label)
                meta.append((subj, trial, seg))
    X = np.stack(X_list, axis=0)  # (N, feat_dim)
    X = X[:, None, :]            # (N, 1, feat_dim)
    y = np.array(y_list, dtype=np.int32)
    return X, y, meta

# ───────────────────────────────────────────────────────────────
# main 실행부
# ───────────────────────────────────────────────────────────────
if __name__ == '__main__':
    if SAVE_FEATURES:
        save_all_features(VIDEO_ROOT, FEATURE_DIR, NUM_SUBJECTS, NUM_SAMPLES, START_SUBJECT)
        sys.exit(0)

    # 1) feature 로드 및 준비
    X, y, meta = prepare_segments_from_saved(FEATURE_DIR, LABEL_ROOT, NUM_SUBJECTS, NUM_SAMPLES)
    print(f"Loaded segments: {X.shape}, labels: {y.shape}")

    # 2) 특정 라벨(예: 5) 제외 예시
    mask = (y < 4)
    X, y, meta = X[mask], y[mask], [m for i,m in enumerate(meta) if mask[i]]
    print(f"After label filtering: {X.shape}, {y.shape}")

    # 3) 라벨 맵 생성
    unique_labels = np.unique(y)
    label_map = {lab: idx for idx, lab in enumerate(unique_labels)}
    y = np.array([label_map[lab] for lab in y], dtype=np.int32)
    NUM_CLASSES = len(unique_labels)
    print(f"Label map: {label_map}")

    # NaN/Inf 제거
    valid = ~np.isnan(X).any(axis=(1,2)) & ~np.isinf(X).any(axis=(1,2))
    X, y = X[valid], y[valid]
    print(f"After clean: {X.shape}, {y.shape}")

    # 정규화
    N, _, D = X.shape
    X_flat = X.reshape(N, D)
    m, s = X_flat.mean(0), X_flat.std(0) + 1e-6
    X = ((X_flat - m) / s).reshape(N, 1, D)

    # train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y)

    # 모델 빌드
    model = build_face_model(
        num_classes=NUM_CLASSES,
        seq_length=X_train.shape[1],
        feature_dim=X_train.shape[2])
    model.compile(
        optimizer=tf.keras.optimizers.Adam(1e-4),
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy'])

    # 콜백
    cp = ModelCheckpoint(
        os.path.join("face_model","best_face.weights.h5"),
        monitor='val_accuracy',
        save_best_only=True,
        save_weights_only=True,    # ← 여기 꼭 추가
        verbose=1
    )
    es = EarlyStopping(
        monitor='val_loss', patience=10, restore_best_weights=True, verbose=1)

    # 학습
    history = model.fit(
        X_train, y_train,
        validation_split=0.2,
        epochs=EPOCHS,
        batch_size=BATCH_SIZE,
        callbacks=[cp, es],
        verbose=2)

    # 평가 & 리포트
    loss, acc = model.evaluate(X_test, y_test, verbose=2)
    print(f"Test Loss: {loss:.4f}, Acc: {acc:.4f}")
    y_pred = model.predict(X_test).argmax(axis=1)
    labels = np.unique(np.concatenate([y_test, y_pred]))
    report = classification_report(y_test, y_pred, labels=labels.tolist(), target_names=[str(l) for l in labels])
    cm = confusion_matrix(y_test, y_pred, labels=labels)
    print(report)
    print("Confusion matrix:\n", cm)

    # 결과 저장
    with open(os.path.join(RESULT_DIR, 'classification_report.txt'), 'w') as f:
        f.write(report)
    np.savetxt(os.path.join(RESULT_DIR, 'confusion_matrix.txt'), cm, fmt='%d')
    
    # 학습곡선 저장
    plt.figure(); plt.plot(history.history['loss'], label='Train Loss'); plt.plot(history.history['val_loss'], label='Val Loss'); plt.legend(); plt.savefig(os.path.join(RESULT_DIR, 'loss_curve.png')); plt.close()
    plt.figure(); plt.plot(history.history['accuracy'], label='Train Acc'); plt.plot(history.history['val_accuracy'], label='Val Acc'); plt.legend(); plt.savefig(os.path.join(RESULT_DIR, 'accuracy_curve.png')); plt.close()
