import argparse
import numpy as np
import cv2
import os
import glob
import re
from scipy.signal import medfilt

def convert_to_gray(frames: np.ndarray) -> np.ndarray:
    """Convert RGB frames to grayscale using vectorized method."""
    return np.dot(frames[..., :3], [0.299, 0.587, 0.114]).astype(np.float32)

def compute_landmark_movement(lm_coords: np.ndarray) -> np.ndarray:
    """Compute per-frame average movement of landmarks."""
    N, P, _ = lm_coords.shape
    mov = np.zeros(N, dtype=np.float32)
    prev = lm_coords[0]
    for i in range(1, N):
        curr = lm_coords[i]
        mov[i] = np.mean(np.linalg.norm(curr - prev, axis=1))
        prev = curr
    return mov

def compute_combined_scores(
    frames: np.ndarray,
    mask: np.ndarray,
    lm_coords: np.ndarray,
    n_base: int,
    w_pixel: float,
    w_flow: float,
    w_landmark: float,
    smooth_kernel: int,
    fb_params: dict
) -> (np.ndarray, np.ndarray):
    valid_idx = np.where(mask)[0]
    if valid_idx.size == 0:
        return np.array([]), valid_idx

    gray = convert_to_gray(frames[valid_idx])       # (N, H, W)
    lm_v = lm_coords[valid_idx]                     # (N, P, 2)

    nb = min(n_base, gray.shape[0] // 2)
    onset    = gray[:nb].mean(axis=0)
    offset   = gray[-nb:].mean(axis=0)
    baseline = (onset + offset) / 2

    pscore = np.mean(np.abs(gray - baseline), axis=(1, 2))

    fscore = np.zeros_like(pscore)
    prev_gray = gray[0]
    for i, curr in enumerate(gray[1:], 1):
        flow = cv2.calcOpticalFlowFarneback(prev_gray, curr, None, **fb_params)
        fscore[i] = np.mean(np.linalg.norm(flow, axis=2))
        prev_gray = curr

    lscore = compute_landmark_movement(lm_v)

    def norm(x):
        return (x - x.min()) / (x.max() - x.min() + 1e-6)
    p = norm(pscore)
    f = norm(fscore)
    l = norm(lscore)

    combined = w_pixel * p + w_flow * f + w_landmark * l

    if smooth_kernel > 1 and smooth_kernel % 2 == 1:
        combined = medfilt(combined, kernel_size=smooth_kernel)
    K = 5
    combined = np.convolve(combined, np.ones(K) / K, mode='same')

    return combined, valid_idx

def find_top_segments(
    combined: np.ndarray,
    valid_idx: np.ndarray,
    length: int,
    num_segments: int
) -> (np.ndarray, np.ndarray):
    if combined.size == 0:
        return np.array([], dtype=int), np.array([], dtype=int)

    half = length // 2
    peak_order = np.argsort(-combined)
    selected_starts = []
    selected_peaks  = []
    occupied = []

    for idx in peak_order:
        peak_frame = valid_idx[idx]
        start = peak_frame - half
        end   = start + length

        # overlap 검사
        if not any(not (end <= s or start >= e) for s, e in occupied):
            selected_starts.append(start)
            selected_peaks.append(peak_frame)
            occupied.append((start, end))
        if len(selected_starts) >= num_segments:
            break

    # 부족한 세그먼트는 padding
    while len(selected_starts) < num_segments:
        selected_starts.append(-half)
        selected_peaks.append(-1)

    return np.array(selected_starts, dtype=int), np.array(selected_peaks, dtype=int)

def pad_or_crop(frames: np.ndarray, start: int, length: int) -> np.ndarray:
    T, H, W, C = frames.shape
    end = start + length

    s = max(start, 0)
    e = min(end, T)
    clipped = frames[s:e]

    pad_before = max(0, -start)
    pad_after  = max(0, end - T)
    if pad_before or pad_after:
        clipped = np.pad(
            clipped,
            ((pad_before, pad_after), (0,0), (0,0), (0,0)),
            mode="constant"
        )

    if clipped.shape[0] > length:
        clipped = clipped[:length]
    elif clipped.shape[0] < length:
        extra = length - clipped.shape[0]
        clipped = np.pad(
            clipped,
            ((0, extra), (0,0), (0,0), (0,0)),
            mode="constant"
        )

    return clipped

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    # hyperparams
    parser.add_argument("--n_base",       type=int,   default=5)
    parser.add_argument("--w_pixel",      type=float, default=1.0)
    parser.add_argument("--w_flow",       type=float, default=0.5)
    parser.add_argument("--w_landmark",   type=float, default=0.5)
    parser.add_argument("--smooth_kernel",type=int,   default=5)
    # Farneback params
    parser.add_argument("--pyr_scale",    type=float, default=0.5)
    parser.add_argument("--levels",       type=int,   default=3)
    parser.add_argument("--winsize",      type=int,   default=15)
    parser.add_argument("--iterations",   type=int,   default=3)
    parser.add_argument("--poly_n",       type=int,   default=5)
    parser.add_argument("--poly_sigma",   type=float, default=1.2)
    # segment settings: 30 frames ≈ 1초 at 30fps
    parser.add_argument("--L",            type=int,   default=30,
                        help="Length (frames) of each segment (≈1 sec at 30fps)")
    parser.add_argument("--num_segments", type=int,   default=8,
                        help="Number of non-overlapping peak segments to extract")
    args = parser.parse_args()

    fb_params = {
        "pyr_scale":   args.pyr_scale,
        "levels":      args.levels,
        "winsize":     args.winsize,
        "iterations":  args.iterations,
        "poly_n":      args.poly_n,
        "poly_sigma":  args.poly_sigma,
        "flags":       0
    }

    VIDEO_ROOT = "/home/bcml1/2025_EMOTION/face_aligned_npy_30fps"
    CLIP_ROOT  = "/home/bcml1/sigenv/_7월/face_micro/restart1_apex8/apex_segments_30frame"
    os.makedirs(CLIP_ROOT, exist_ok=True)

    all_npz = sorted(glob.glob(os.path.join(VIDEO_ROOT, "s*_trial*.npz")))
    npz_files = [
        f for f in all_npz
        if (m := re.search(r"s(\d+)_trial", os.path.basename(f)))
        and 9 <= int(m.group(1)) <= 22
    ]

    for npz_file in npz_files:
        data   = np.load(npz_file)
        frames = data["data"]
        mask   = data["detect_mask"] | data["fallback_mask"]
        lm     = data["landmarks"]

        combined, valid_idx = compute_combined_scores(
            frames, mask, lm,
            args.n_base,
            args.w_pixel, args.w_flow, args.w_landmark,
            args.smooth_kernel,
            fb_params
        )

        # 30프레임 세그먼트에 맞춰 start & peak indices 추출
        starts, peak_timestamps = find_top_segments(
            combined, valid_idx,
            args.L, args.num_segments
        )

        peak_timestamps = peak_timestamps  # 각 세그먼트 윈도우의 peak 인덱스 (90 frame 중 45번 frame)

        # --- extract Onset/Peak/Offset per segment ---
        triple_clips = []
        for st in starts:
            onset  = pad_or_crop(frames, st - args.L, args.L)
            peak   = pad_or_crop(frames, st,         args.L)
            offset = pad_or_crop(frames, st + args.L, args.L)
            triple_clips.append(np.stack([onset, peak, offset], axis=0))

        multi_clips   = np.stack(triple_clips, axis=0)
        onset_clips   = multi_clips[:, 0]
        peak_clips    = multi_clips[:, 1]
        offset_clips  = multi_clips[:, 2]

        basename = os.path.splitext(os.path.basename(npz_file))[0]
        out_path = os.path.join(CLIP_ROOT, f"{basename}.npz")

        np.savez_compressed(
            out_path,
            multi_clip=multi_clips,
            onset_clip=onset_clips,
            peak_clip=peak_clips,
            offset_clip=offset_clips,
            mask=mask,
            peak_timestamps=peak_timestamps
        )
        print(f"{basename} → saved {multi_clips.shape}, peaks at {peak_timestamps.tolist()} to {out_path}")
